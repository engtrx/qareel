package com.qareeb

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private val client by lazy { Nearby.getConnectionsClient(this) }
    private val linked = java.util.Collections.synchronizedSet(HashSet<String>())
    private val service = "com.qareeb.chat"
    private var myId = ""
    private var started = false
    private var rec: MediaRecorder? = null
    private var recFile: File? = null
    private var imgKind = ""
    private var imgMax = 640
    private var imgQ = 60

    private fun emit(o: JSONObject) {
        web.post { web.evaluateJavascript("window.onNative(" + JSONObject.quote(o.toString()) + ")", null) }
    }

    private fun err(m: String) = emit(JSONObject().put("t", "err").put("m", m))

    // ---- الصلاحيات ----
    private fun nearbyPerms(): List<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_ADVERTISE
            l += Manifest.permission.BLUETOOTH_CONNECT
            l += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT <= 31) l += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.NEARBY_WIFI_DEVICES
        return l
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (myId.isNotEmpty() && nearbyPerms().all { granted(it) }) startNet()
        else err("اسمح بالصلاحيات المطلوبة ثم أعد فتح التطبيق")
    }

    // ---- Nearby Connections (بلوتوث مع ترقية تلقائية لـ Wi-Fi) ----
    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            p.asBytes()?.let { emit(JSONObject().put("t", "msg").put("e", id).put("d", String(it, Charsets.UTF_8))) }
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    private val life = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            client.acceptConnection(id, payloads)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                linked.add(id)
                emit(JSONObject().put("t", "up").put("e", id))
            }
        }
        override fun onDisconnected(id: String) {
            linked.remove(id)
            emit(JSONObject().put("t", "down").put("e", id))
        }
    }

    private val disc = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            // الجهاز ذو المعرّف الأصغر هو من يطلب الاتصال لتفادي التعارض
            if (myId < info.endpointName && !linked.contains(id)) {
                client.requestConnection(myId, id, life).addOnFailureListener { }
            }
        }
        override fun onEndpointLost(id: String) {}
    }

    private fun startNet() {
        if (started) return
        started = true
        client.startAdvertising(
            myId, service, life,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { started = false; err("تعذر البث: " + it.message) }
        client.startDiscovery(
            service, disc,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { started = false; err("تعذر البحث: " + it.message) }
    }

    // ---- اختيار صورة وتصغيرها ----
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Thread {
            try {
                val op = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, op) }
                var ss = 1
                while (maxOf(op.outWidth, op.outHeight) / ss > imgMax * 2) ss *= 2
                val bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss })
                } ?: return@Thread
                val s = imgMax.toFloat() / maxOf(bmp.width, bmp.height)
                val b = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true) else bmp
                val o = ByteArrayOutputStream()
                b.compress(Bitmap.CompressFormat.JPEG, imgQ, o)
                emit(JSONObject().put("t", "img").put("k", imgKind).put("d", Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)))
            } catch (e: Exception) {
                err("تعذر قراءة الصورة")
            }
        }.start()
    }

    // ---- الجسر بين الواجهة والنظام ----
    inner class Bridge {
        @JavascriptInterface
        fun start(id: String) {
            runOnUiThread {
                myId = id
                val need = nearbyPerms() + Manifest.permission.RECORD_AUDIO
                if (nearbyPerms().all { granted(it) }) {
                    startNet()
                    if (!granted(Manifest.permission.RECORD_AUDIO)) permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                } else permLauncher.launch(need.toTypedArray())
            }
        }

        @JavascriptInterface
        fun send(d: String, except: String) {
            val t = synchronized(linked) { linked.filter { it != except } }
            if (t.isNotEmpty()) client.sendPayload(t, Payload.fromBytes(d.toByteArray(Charsets.UTF_8)))
        }

        @JavascriptInterface
        fun sendTo(e: String, d: String) {
            client.sendPayload(e, Payload.fromBytes(d.toByteArray(Charsets.UTF_8)))
        }

        @JavascriptInterface
        fun pickImage(kind: String, max: Int, q: Int) {
            imgKind = kind; imgMax = max; imgQ = q
            runOnUiThread { picker.launch("image/*") }
        }

        @JavascriptInterface
        fun startRec() {
            runOnUiThread {
                try {
                    val f = File(cacheDir, "r.m4a"); recFile = f
                    @Suppress("DEPRECATION")
                    val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this@MainActivity) else MediaRecorder()
                    r.setAudioSource(MediaRecorder.AudioSource.MIC)
                    r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    r.setAudioEncodingBitRate(24000)
                    r.setAudioSamplingRate(16000)
                    r.setAudioChannels(1)
                    r.setOutputFile(f.absolutePath)
                    r.prepare(); r.start(); rec = r
                } catch (e: Exception) {
                    rec = null
                    err("تعذر التسجيل، اسمح بالميكروفون")
                }
            }
        }

        @JavascriptInterface
        fun stopRec() {
            runOnUiThread {
                val r = rec ?: return@runOnUiThread
                try { r.stop() } catch (e: Exception) { }
                r.release(); rec = null
                recFile?.let {
                    if (it.length() > 0)
                        emit(JSONObject().put("t", "audio").put("d", Base64.encodeToString(it.readBytes(), Base64.NO_WRAP)))
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.goBack?window.goBack():0") { r ->
                    if (r != "1") { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
    }
}
